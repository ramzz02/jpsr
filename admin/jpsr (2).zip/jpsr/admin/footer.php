
                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                Copyright <script>document.write(new Date().getFullYear())</script> &copy; JPSR Enterprises. Powered by <a href="https://sensitive.co.in">Sensitive Technologies</a> 
                            </div>
                            <div class="col-md-6">
                                <div class="text-md-end footer-links d-none d-sm-block">
                                    <a href="javascript:void(0);">About Us</a>
                                    <a href="javascript:void(0);">Help</a>
                                    <a href="javascript:void(0);">Contact Us</a>
                                </div>
                            </div>
							</div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->

<?php include("right-sidebar.php"); ?>

        <!-- Right bar overlay-->
        <div class="rightbar-overlay"></div>

        <!-- Vendor js -->
        <script src="js/vendor.min.js"></script>

        <!-- Plugins js -->
        <script src="libs/morris.js06/morris.min.js"></script>
        <script src="libs/raphael/raphael.min.js"></script>

        <!-- Dashboard init-->
        <script src="js/pages/dashboard-4.init.js"></script>

        <!-- App js -->
        <script src="js/app.min.js"></script>
		<script src="libs/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
        <script src="libs/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
        <script src="libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js"></script>
        <script src="libs/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
        <script src="libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
        <script src="libs/datatables.net-buttons/js/buttons.html5.min.js"></script>
        <script src="libs/datatables.net-buttons/js/buttons.flash.min.js"></script>
        <script src="libs/datatables.net-buttons/js/buttons.print.min.js"></script>
        <script src="libs/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
        <script src="libs/datatables.net-select/js/dataTables.select.min.js"></script>
        <script src="libs/pdfmake/build/pdfmake.min.js"></script>
        <script src="libs/pdfmake/build/vfs_fonts.js"></script>
        <script src="js/pages/datatables.init.js"></script>
		<script src="../js/states.js"></script>
		        <!-- Plugins js -->
        <script src="libs/dropzone/min/dropzone.min.js"></script>
        <script src="libs/dropify/js/dropify.min.js"></script>

        <!-- Init js-->
        <script src="js/pages/form-fileuploads.init.js"></script>
    </body>
</html>