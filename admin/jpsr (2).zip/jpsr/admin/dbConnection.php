<?php
$con= mysqli_connect('localhost','root','','jpsr');
if(!$con)
{
 die('could not connect;'.mysqli_connect_error());
}
?>