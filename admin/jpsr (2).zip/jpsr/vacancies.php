<?php include("dashboardtopheader.php"); ?>
			</div>
            <div class="row">
				<div class="col-md-6 col-lg-6 col-xl-6">
					<a href="jobs.php"><div class="why_chose_us">
						<div class="icon">
							<span class="fa fa-briefcase"></span>
						</div>
						<div class="details">
							<h4>Search Job</h4>
							<p>Search for a suitable Job and get yourself placed where you are fit into and grow.</p>
						</div>
					</div></a>
				</div>
				<div class="col-md-6 col-lg-6 col-xl-6">
					<a href="searchEmployee.php"><div class="why_chose_us">
						<div class="icon">
							<span class="fa fa-users"></span>
						</div>
						<div class="details">
							<h4>Search Employee</h4>
							<p>Recruit a desired candidate who is a best match for the available positions.</p>
						</div>
					</div></a>
				</div>
			</div>
		</div>
	</section>
<?php include("footer.php");?>