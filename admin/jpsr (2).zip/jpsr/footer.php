	<!-- Our Footer -->
	<section class="footer_one">
		<div class="container pb70">
			<div class="row">
				<div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
					<div class="footer_contact_widget">
						<h4><i class="fa fa-phone-square"></i> Contact Us</h4><hr>
						<ul class="list-unstyled">
							<li class="text-white df"><span class="flaticon-pin mr15"></span><a href="#">Hosur, Tamilnadu.</a></li>
							<!--li class="text-white"><span class="flaticon-phone mr15"></span><a href="#">+123 456 7890</a></li-->
							<li class="text-white"><span class="flaticon-email mr15"></span><a href="#">info@jpsr.in</a></li>
						</ul>
						<hr>
						<ul class="mb0">
							<li class="list-inline-item"><a href="#"><i class="fa fa-facebook"></i></a></li>
							<li class="list-inline-item"><a href="#"><i class="fa fa-twitter"></i></a></li>
							<li class="list-inline-item"><a href="#"><i class="fa fa-instagram"></i></a></li>
							<li class="list-inline-item"><a href="#"><i class="fa fa-linkedin"></i></a></li>
							<li class="list-inline-item"><a href="#"><i class="fa fa-pinterest"></i></a></li>
							<li class="list-inline-item"><a href="#"><i class="fa fa-youtube"></i></a></li>
							<li class="list-inline-item"><a href="#"><i class="fa fa-google"></i></a></li>
							<li class="list-inline-item"><a href="https://wa.me/919715020000?text=*I%20Need*%0Amore%20info%20on%20JPSR"><i class="fa fa-whatsapp"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
					<div class="footer_qlink_widget pl0">
						<h4><i class="fa fa-edit"></i> Read More...</h4><hr>
						<ul class="list-unstyled">
							<li><a href="about.php"><i class="fa fa-briefcase"></i> About Us</a></li>
							<li><a href="#"><i class="fa fa-edit"></i> Terms & Service</a></li>
							<li><a href="#"><i class="fa fa-print"></i> Priacy Policy</a></li>
							<li><a href="hosurtransformation.php"><i class="fa fa-street-view"></i> Hosur Transformation</a></li>
							<li><a href="hosurchat.php"><i class="fa fa-comments"></i> Hosur Chat</a></li>
							<li><a href="pricelist.php"><i class="fa fa-rupee"></i> Pricelist</a></li>
							<li><a href="contact.php"><i class="fa fa-phone-square"></i> Contact Us</a></li>
						</ul>
					</div>
				</div>
				<div class="col-sm-6 col-md-6 col-lg-4 col-xl-4">
					<div class="footer_social_widget">
					    
						<hr><p class="text-white mb20">We are available on Android & IOS.</p>
						<h4><i class="fa fa-envelope"></i> Download Our App</h4>
						<form class="footer_mailchimp_form">
						 	<div class="form-row align-items-center">
							    	<p><a href="https://play.google.com/store/apps/details?id=com.app.jpsr"><img src="images/android.png" width="100px"></a> | 
							    	<a href="https://play.google.com/store/apps/details?id=com.app.jpsr"><img src="images/apple.png" width="100px"></a></p>
						  	</div>
						</form><hr>
					</div>
				</div>
			</div>
		</div>
		<hr>
		<div class="container pt20 pb30">
			<div class="row">
				<div class="col-md-4 col-lg-4">
					<div class="copyright-widget mt10 mb15-767">
						<p>Copyright © 2021. All Rights Reserved to JPSR.</p>
					</div>
				</div>
				<div class="col-md-4 col-lg-4">
					<div class="footer_logo_widget text-center mb15-767">
						<div class="wrapper">
							<div class="logo text-center">
								<img src="images/logo.png" alt="JPSR" width="100px">
					            <span class="logo_title text-white pl15"></span>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-4 col-lg-4">
					<div class="footer_social_widget text-right tac-smd mt10">
					Powered by <a href="https://sensitive.co.in">JPSR Enterprises.</a>
					</div>
				</div>
			</div>
		</div>
	</section>

<a class="scrollToHome" href="#"><i class="fa fa-angle-up"></i></a>
</div>
<!-- Wrapper End -->
<script src="js/jquery-3.6.0.js"></script>
<script src="js/jquery-migrate-3.0.0.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.mmenu.all.js"></script>
<script src="js/ace-responsive-menu.js"></script>
<script src="js/bootstrap-select.min.js"></script>
<script src="js/isotop.js"></script>
<script src="js/snackbar.min.js"></script>
<script src="js/simplebar.js"></script>
<script src="js/parallax.js"></script>
<script src="js/scrollto.js"></script>
<script src="js/jquery-scrolltofixed-min.js"></script>
<script src="js/jquery.counterup.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/progressbar.js"></script>
<script src="js/slider.js"></script>
<script src="js/timepicker.js"></script>
<!-- Custom script for all pages --> 
<script src="js/jquery.smartuploader.js"></script>
<script src="js/dashboard-script.js"></script>
<script src="js/google-map-api.js"></script>
<script src="js/googlemaps1.js"></script>
<!-- Custom script for all pages --> 
<script src="js/script.js"></script>
<script src="js/states.js"></script>
	<script src="https://www.google.com/recaptcha/api.js"></script>
<script>
$(function() {
    // Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            var filesAmount = input.files.length;

            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();

                reader.onload = function(event) {
                    $($.parseHTML('<img width="150px">')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                }

                reader.readAsDataURL(input.files[i]);
            }
        }

    };

    $('#gallery-photo-add').on('change', function() {
        imagesPreview(this, 'div.gallery');
    });
});
</script>
<script>
			grecaptcha.ready(function() {
			grecaptcha.execute('6Lf5lFocAAAAAFW6eeW40XMEiSfo-SwhmFE-p4zu', {action: 'https://jpsr.in'}).then(function(token) {
			...
			});
			});
</script>
<script>
	$(document).ready(function()
{
	$("#one").hide();   
	$("#two").hide();
    $("#category").change(function()
	{
	   
	
		var name=$('#category').val();

			if(name=='news')
		{
	$("#one").hide();   
	$("#two").show();   
	
			}
			if(name=='business')
		{
	$("#one").show();   
	$("#two").hide();   
	
			}
	
	});
});
</script>

</body>
</html>