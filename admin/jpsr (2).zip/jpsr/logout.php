<?php 
	session_start();
$_SESSION = array();
session_destroy();
$url=$_POST['url'];
//if(!isset($_SESSION['login_username'])){
        header("location:".$url);
        //exit();
    //}
?>