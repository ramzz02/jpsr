<li><a class="active" href="classifieds.php"><span class="flaticon-web-page"></span> Classifieds</a></li>
<li><a href="profile.php"><span class="flaticon-avatar"></span> Profile</a></li>

<li><a href="businesslisting.php"><span class="flaticon-list"></span> Business Listings</a></li>
<li><a href="mylistings.php"><span class="flaticon-edit"></span> Other Submission</a></li>
<li><a href="user-jpsr-services.php"><span class="fa fa-cogs"></span> JPSR Services</a></li>
<li><a href="myoffers.php"><span class="flaticon-chat"></span> Offers</a></li>
<li><a href="logout.php"><span class="flaticon-logout"></span> Logout</a></li>